# ClipForge AI — Gaming Video Highlights

A beginner-friendly Streamlit app that analyzes gameplay recordings for high visual-change moments, suggests timestamps, and exports selected clips.

## Features
- Upload MP4, MOV, or AVI gameplay video
- Sample frames and score visual changes
- Suggest highlight timestamps
- Download timestamps as CSV
- Export selected moments as MP4 clips in a ZIP file

## Important limitation
This prototype detects visual changes, not actual kills, headshots, or game events. Treat the suggestions as moments to review. Video export compatibility can vary with the uploaded file and hosting environment.

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the app:
   ```bash
   streamlit run app.py
   ```

## Publish free with Streamlit Community Cloud
1. Create/sign in to a GitHub account.
2. Create a new **public** repository, e.g. `clipforge-ai`.
3. Upload `app.py`, `requirements.txt`, and `README.md` to the repository root.
4. Open https://share.streamlit.io/ and connect GitHub.
5. Choose **Create app**, select the repository, branch `main`, and main file path `app.py`.
6. Click **Deploy** and wait for the app to build.
7. Copy the generated `*.streamlit.app` URL to share your website.

Official guide: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app

## Tips
- Start with a short gameplay video and keep it under 200 MB.
- Use videos you own or have permission to edit and share.
- Free hosting has resource limits, and large videos may take too long to process.
