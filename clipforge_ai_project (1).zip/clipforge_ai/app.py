import io
import csv
import zipfile
import tempfile
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="ClipForge AI", page_icon="🎮", layout="wide")

st.markdown("""
<style>
.main {background: linear-gradient(135deg, #10131f 0%, #171c2e 55%, #111827 100%);}
.hero {padding: 1.2rem 1.4rem; border: 1px solid #333b55; border-radius: 18px;
       background: linear-gradient(120deg, #222844, #171c2e);}
.hero h1 {margin: 0; color: #ffffff;}
.hero p {color: #c7cce0; margin-bottom: 0;}
div[data-testid="stMetric"] {background:#1c2236; padding:12px; border-radius:12px;}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
  <h1>🎮 ClipForge AI</h1>
  <p>Find action-heavy moments in your gameplay recording and turn them into shareable clips.</p>
</div>
""", unsafe_allow_html=True)
st.write("Upload a gameplay video. ClipForge samples frames, scores visual changes, and suggests moments worth reviewing.")

with st.expander("How it works", expanded=False):
    st.write(
        "This beginner prototype uses frame-to-frame visual change as a proxy for action. "
        "It does not truly understand kills, headshots, or game events, so check the suggested clips before sharing."
    )

uploaded = st.file_uploader("Upload gameplay video (MP4, MOV, or AVI)", type=["mp4", "mov", "avi"])
left, right = st.columns(2)
with left:
    clip_length = st.slider("Clip length (seconds)", min_value=5, max_value=30, value=12, step=1)
with right:
    number_clips = st.slider("Number of highlight suggestions", min_value=1, max_value=8, value=3, step=1)

def format_time(seconds):
    seconds = max(0, int(seconds))
    return f"{seconds // 60:02d}:{seconds % 60:02d}"

def analyze_video(video_path, sample_every=0.5, max_width=320):
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise ValueError("Could not open this video. Try exporting it as MP4 and upload again.")
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_count = cap.get(cv2.CAP_PROP_FRAME_COUNT)
    if not fps or fps <= 0 or not frame_count or frame_count <= 0:
        cap.release()
        raise ValueError("Could not read the video's duration or frame rate.")
    duration = frame_count / fps
    if duration > 15 * 60:
        cap.release()
        raise ValueError("For this demo, please upload a video shorter than 15 minutes.")
    sample_step = max(1, int(fps * sample_every))
    samples = []
    prev_gray = None
    frame_index = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if frame_index % sample_step == 0:
            h, w = frame.shape[:2]
            new_w = min(max_width, w)
            new_h = max(1, int(h * new_w / w))
            small = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_AREA)
            gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            if prev_gray is not None:
                score = float(np.mean(cv2.absdiff(gray, prev_gray)))
                samples.append((frame_index / fps, score))
            prev_gray = gray
        frame_index += 1
    cap.release()
    if len(samples) < 3:
        raise ValueError("This video is too short to analyze. Try a longer recording.")
    return duration, fps, samples

def choose_highlights(samples, duration, count, clip_len):
    # Smooth nearby measurements so single noisy frames are less likely to dominate.
    times = np.array([x[0] for x in samples], dtype=float)
    scores = np.array([x[1] for x in samples], dtype=float)
    window = 3
    smooth = np.convolve(scores, np.ones(window) / window, mode="same") if len(scores) >= window else scores
    order = np.argsort(smooth)[::-1]
    selected = []
    min_gap = max(clip_len * 0.75, 8)
    for idx in order:
        center = float(times[idx])
        start = max(0.0, center - clip_len / 2)
        end = min(duration, start + clip_len)
        start = max(0.0, end - clip_len)
        if all(abs(center - item["center"]) >= min_gap for item in selected):
            selected.append({
                "rank": len(selected) + 1,
                "center": center,
                "start": start,
                "end": end,
                "score": float(smooth[idx])
            })
        if len(selected) >= count:
            break
    selected.sort(key=lambda x: x["start"])
    for i, item in enumerate(selected, start=1):
        item["rank"] = i
    return selected

def render_clip(source_path, start, end, fps, out_path):
    cap = cv2.VideoCapture(str(source_path))
    if not cap.isOpened():
        raise ValueError("Could not reopen uploaded video.")
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    source_fps = cap.get(cv2.CAP_PROP_FPS)
    if not source_fps or source_fps <= 0:
        source_fps = fps
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(str(out_path), fourcc, source_fps, (width, height))
    if not writer.isOpened():
        cap.release()
        raise ValueError("Could not create MP4 clips in this environment.")
    cap.set(cv2.CAP_PROP_POS_MSEC, start * 1000)
    frame_limit = int(max(1, (end - start) * source_fps))
    written = 0
    while written < frame_limit:
        ok, frame = cap.read()
        if not ok:
            break
        writer.write(frame)
        written += 1
    writer.release()
    cap.release()
    return written

if uploaded:
    if uploaded.size > 200 * 1024 * 1024:
        st.error("This demo accepts files up to 200 MB. Try a shorter or lower-resolution recording.")
        st.stop()

    st.video(uploaded)
    if st.button("🔎 Analyze gameplay", type="primary", use_container_width=True):
        with st.spinner("Analyzing sampled frames..."):
            try:
                with tempfile.TemporaryDirectory() as tmp:
                    tempdir = Path(tmp)
                    source = tempdir / uploaded.name
                    source.write_bytes(uploaded.getvalue())
                    duration, fps, samples = analyze_video(source)
                    highlights = choose_highlights(samples, duration, number_clips, clip_length)
                    st.session_state["analysis"] = {
                        "video_bytes": uploaded.getvalue(),
                        "name": uploaded.name,
                        "duration": duration,
                        "fps": fps,
                        "samples": samples,
                        "highlights": highlights,
                    }
            except Exception as exc:
                st.error(str(exc))

analysis = st.session_state.get("analysis")
if analysis:
    st.subheader("Your suggested highlights")
    m1, m2, m3 = st.columns(3)
    m1.metric("Video duration", format_time(analysis["duration"]))
    m2.metric("Moments found", len(analysis["highlights"]))
    m3.metric("Analysis samples", len(analysis["samples"]))

    rows = []
    for item in analysis["highlights"]:
        rows.append({
            "Highlight": f"Moment {item['rank']}",
            "Start": format_time(item["start"]),
            "End": format_time(item["end"]),
            "Center timestamp (seconds)": round(item["center"], 2),
            "Visual activity score": round(item["score"], 2)
        })
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    st.caption("Higher activity score means more visual change, not guaranteed kills or highlights.")

    csv_bytes = pd.DataFrame(rows).to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download timestamps (CSV)", data=csv_bytes,
                       file_name="clipforge_highlight_timestamps.csv", mime="text/csv")

    st.subheader("Export highlight clips")
    st.write("Choose the clips you want to export. Processing may take a little time.")
    selected_ranks = st.multiselect(
        "Select moments",
        options=[item["rank"] for item in analysis["highlights"]],
        default=[item["rank"] for item in analysis["highlights"][:min(3, len(analysis["highlights"]))]],
        format_func=lambda rank: f"Moment {rank}"
    )
    if st.button("✂️ Create selected clips", use_container_width=True):
        if not selected_ranks:
            st.warning("Select at least one moment.")
        else:
            with st.spinner("Creating clips..."):
                try:
                    with tempfile.TemporaryDirectory() as tmp:
                        tempdir = Path(tmp)
                        source = tempdir / "uploaded_gameplay.mp4"
                        source.write_bytes(analysis["video_bytes"])
                        output_files = []
                        for rank in selected_ranks:
                            item = next(x for x in analysis["highlights"] if x["rank"] == rank)
                            out = tempdir / f"moment_{rank}.mp4"
                            render_clip(source, item["start"], item["end"], analysis["fps"], out)
                            output_files.append((f"moment_{rank}.mp4", out.read_bytes()))
                        zip_buffer = io.BytesIO()
                        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
                            for filename, content in output_files:
                                zf.writestr(filename, content)
                        st.download_button(
                            "⬇️ Download highlight clips (ZIP)",
                            data=zip_buffer.getvalue(),
                            file_name="clipforge_highlights.zip",
                            mime="application/zip"
                        )
                        st.success("Clips are ready. Use the download button above.")
                except Exception as exc:
                    st.error(f"Could not export clips: {exc}")
    st.info("Tip: For better results, try a short 1–3 minute gameplay recording first.")

st.markdown("---")
st.caption("ClipForge AI • Beginner prototype • Your uploaded video is processed for this session and is not saved as a public post.")
